<?php // Silence is Golden.
